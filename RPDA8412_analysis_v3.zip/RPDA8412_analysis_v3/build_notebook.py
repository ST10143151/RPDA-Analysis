"""Builds analysis.ipynb from analysis.py (percent format). Usage: python build_notebook.py"""
import re, nbformat
src = open("analysis.py").read()
cells = re.split(r"(?m)^# %%(?: \[markdown\])?\n", src)[1:]
heads = re.findall(r"(?m)^# %%( \[markdown\])?\n", src)
nb = nbformat.v4.new_notebook()
for h, c in zip(heads, cells):
    c = c.rstrip("\n")
    if h:
        nb.cells.append(nbformat.v4.new_markdown_cell("\n".join(l[2:] if l.startswith("# ") else l.lstrip("#") for l in c.split("\n"))))
    else:
        nb.cells.append(nbformat.v4.new_code_cell(c))
nb.metadata["kernelspec"] = {"display_name": "Python 3", "language": "python", "name": "python3"}
nbformat.write(nb, "analysis.ipynb")
print(len(nb.cells), "cells")
