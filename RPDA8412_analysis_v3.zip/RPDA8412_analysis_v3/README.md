# RPDA8412w - Credit card fraud detection analysis (reproducible)

Researcher: Ananta Reddy (ST10143151) | Supervisor: Prof Meera K. Joseph | Programme: PDDA, Emeris (The IIE)

This folder holds the code and results for the RPDA8412w Summative Research Report
*"Using Machine Learning to Detect Anonymized Credit Card Fraud in Digital Banking Transactions"*.

## Dataset and citation
- **Dataset:** Credit Card Fraud Detection - Machine Learning Group, Université Libre de Bruxelles (ULB). Kaggle: <https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud> ("mlg-ulb/creditcardfraud").
- **Please cite:** Dal Pozzolo, A., Caelen, O., Johnson, R.A. and Bontempi, G., 2015. Calibrating probability with undersampling for unbalanced classification. In: *2015 IEEE Symposium Series on Computational Intelligence*. IEEE, pp.159-166. And: Machine Learning Group - ULB, 2018. *Credit Card Fraud Detection*. Kaggle.
- **Copy actually used:** Kaggle needs an account login, so the public copy of the same file hosted by TensorFlow was used: <https://storage.googleapis.com/download.tensorflow.org/data/creditcard.csv> (saved as `data/creditcard.csv`, MD5 `e90efcb83d69faf99fcab8b0255024de`).
- **Verified (see `results/dataset_verification.json`):** 284,807 rows x 31 columns; 492 frauds (0.1727%); 284,315 legitimate; 0 missing values; 1,081 duplicate rows (kept). The published OpenML metadata for the same dataset (data_id 1597, "creditcard": 284,807 instances, 31 features, 492 fraud / 284,315 legitimate, 0 missing) matches the local file (`results/openml_metadata_crosscheck.json`). A row-by-row comparison with the OpenML ARFF was attempted but its 150 MB download kept stalling, so it was not done; `dataset_verification.json` therefore shows `openml_crosscheck: skipped`.
- Kaggle's own published checksum could not be checked (login required).

## Contents
| File | What it is |
|---|---|
| `analysis.ipynb` | Executed notebook (all outputs saved). Commented, runs top to bottom. |
| `analysis.py` | Same code in percent-cell format (`# %%`), runnable as a script or in VS Code/Jupytext. |
| `build_notebook.py` | Rebuilds `analysis.ipynb` from `analysis.py`. |
| `results/*.csv` | Result tables (summary, CV, tuned-threshold, bootstrap CIs, McNemar, feature importance, hyperparameters, etc.). |
| `results/figures/*.png` | Charts (class distribution, PR/ROC curves, confusion matrices, feature importance, threshold analysis, ...). |
| `results/scores_val_test.npz` | Saved validation/test scores of every model (for re-plotting without refitting). |

## How to reproduce
```bash
python3 -m venv venv && source venv/bin/activate        # Python 3.13 used (3.10+ should work)
pip install numpy pandas scikit-learn imbalanced-learn xgboost matplotlib seaborn scipy statsmodels joblib jupyter nbconvert
# put creditcard.csv in ./data/ (downloaded automatically from the TensorFlow mirror if missing)
jupyter nbconvert --to notebook --execute --inplace analysis.ipynb    # or: python analysis.py
```
Runtime is roughly 15-30 minutes on an 8-core machine. Everything random uses `SEED = 42`. Library versions used: scikit-learn 1.9.1, imbalanced-learn 0.14.2, xgboost 3.4.1, pandas 3.1.0, numpy 2.5.4, scipy 1.18.1, Python 3.13.5.

## Method (what the notebook does)
1. Load and verify the dataset (counts, checksum, duplicates, optional OpenML cross-check).
2. EDA: class distribution, Amount/Time by class.
3. **Stratified 70/15/15 split** (train 199,364 / validation 42,721 / test 42,722; fraud 344 / 74 / 74).
4. Pipelines (`imblearn.Pipeline`): z-score scaling of `Time` and `Amount` only -> optional SMOTE (training data only) -> classifier. Scaling and SMOTE are fitted inside each CV fold.
5. Models x conditions: Logistic Regression, Random Forest, **SVM (RBF on a stratified 50,000-row training subsample)**, Gradient Boosting (XGBoost), plus a supplementary **LinearSVC on the full training set**; conditions = Baseline, SMOTE (minority:majority ratio 0.10, k=5), Cost-sensitive (`class_weight="balanced"` / `scale_pos_weight`).
6. Hyperparameters chosen on the **validation set** from small pre-specified grids (PR-AUC).
7. **Stratified 5-fold CV** on the training set (mean +/- SD).
8. Final fit on the full training set; test metrics at the default threshold and at the validation-F1-optimal threshold: precision, recall, F1, ROC-AUC, PR-AUC, MCC, confusion matrices.
9. Best model chosen by **validation** PR-AUC (not test). Bootstrap 95% CIs (1,000 stratified resamples) and McNemar exact tests vs the best model. PR/ROC curves, feature importances, threshold analysis.

## Methodological differences from the proposal
1. **Split/validation design:** the proposal says 70/15/15; the 16 Aug 2026 refinement document says a 20% test set with 5-fold CV on the other 80%. This analysis uses 70/15/15 **and** 5-fold CV on the 70% training set.
2. **SVM:** RBF-SVM on a stratified 50k-row subsample (only 86 frauds) rather than on all training data (compute cost); LinearSVC on the full data added. The RBF-SVM's weaker results may partly reflect the subsample.
3. **Gradient boosting:** XGBoost only (proposal allowed XGBoost or LightGBM).
4. **Imbalance conditions:** Baseline / SMOTE / cost-sensitive for every model. The proposal's third technique ("ensemble-based, no explicit rebalancing") is identical to the Baseline for RF and XGBoost.
5. **Not tuned:** SMOTE ratio (fixed at 0.10) and class-weight values (balanced only) - the proposal said the weighting would be validated.
6. **Hyperparameter search:** small pre-specified validation-set grids, not RandomizedSearchCV and not exhaustive.
7. **Statistics:** McNemar exact test and bootstrap CIs; **DeLong's test was not run** (only 74 test frauds). McNemar p-values are not corrected for 14 comparisons.
8. **Data and security:** public mirror of the Kaggle file; Kaggle checksum not verified; analysis ran in a cloud workspace, not on a locally encrypted machine as the proposal's ethics section states.
9. **Plan/timeline:** the Semester 2 timeline and six weekly phases in the proposal were not followed (the analysis was executed on 2 Nov 2026).
10. **Not covered:** demographic fairness evaluation; deep-learning/GAN comparisons; XGBoost/LightGBM comparison; temporal (out-of-time) validation (random split used).

## Caveats
- The test set has only 74 frauds, so each missed fraud changes recall by ~1.4 points; CIs are wide and several differences between the top models are not statistically distinguishable.
- Duplicate rows were not removed and may appear in both train and test.
- The original methodology proposal and the 16 August 2026 refinement are distinct reference documents;
