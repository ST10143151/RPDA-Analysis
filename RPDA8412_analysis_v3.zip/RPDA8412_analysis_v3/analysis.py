# %% [markdown]
# # RPDA8412w Research Project - Analysis notebook
# **Title:** Using Machine Learning to Detect Anonymized Credit Card Fraud in Digital Banking Transactions
# **Researcher:** Ananta Reddy (ST10143151) | **Supervisor:** Prof Meera K. Joseph
#
# This notebook executes the methodology set out in the approved proposal (Proposal Revision 4) and the
# Methodology Refinement (Aug 2026): four supervised models x three imbalance conditions
# (baseline / SMOTE / cost-sensitive), a stratified 70/15/15 split, SMOTE and scaling fitted on training data only,
# stratified 5-fold cross-validation on the training set, and evaluation on a held-out test set.
#
# **Data:** Dal Pozzolo, A., Caelen, O., Johnson, R.A. and Bontempi, G. (2015) / ULB Machine Learning Group,
# *Credit Card Fraud Detection*, Kaggle: https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud
#
# **Reproducibility:** every random process uses `SEED = 42`. Run top to bottom (about 20-40 min on 8 cores).
#
# **Verification:** Re-run all code cells and check the resulting metrics and figures before referencing them in the report.
# Record the use of external assistance in the academic integrity declaration, as required.

# %%
import os
import sys
import time
import json
import hashlib
import random
import warnings
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import sklearn
import imblearn
import xgboost
import scipy
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_validate
from sklearn.preprocessing import StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC, LinearSVC
from xgboost import XGBClassifier
from imblearn.pipeline import Pipeline
from imblearn.over_sampling import SMOTE
from sklearn.metrics import (precision_score, recall_score, f1_score, roc_auc_score, average_precision_score,
                             matthews_corrcoef, confusion_matrix, precision_recall_curve, roc_curve)
from statsmodels.stats.contingency_tables import mcnemar
from joblib import Parallel, delayed

warnings.filterwarnings("ignore")
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
ROOT = Path(os.getcwd())
DATA = ROOT / "data" / "creditcard.csv"
RES = ROOT / "results"
FIG = RES / "figures"
RES.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)
sns.set_theme(style="whitegrid", context="notebook")
print({k: v.__version__ for k, v in dict(python=sys, sklearn=sklearn, imblearn=imblearn, xgboost=xgboost,
      pandas=pd, numpy=np, scipy=scipy).items() if hasattr(v, "__version__")}, sys.version.split()[0])

# %% [markdown]
# ## 1. Data acquisition and verification
# The Kaggle file needs credentials, so the identical public copy hosted by TensorFlow
# (`https://storage.googleapis.com/download.tensorflow.org/data/creditcard.csv`) was used and cross-checked
# against the OpenML copy (data_id 1597 / "creditcard") when available.

# %%
if not DATA.exists():
    import urllib.request
    DATA.parent.mkdir(exist_ok=True)
    urllib.request.urlretrieve("https://storage.googleapis.com/download.tensorflow.org/data/creditcard.csv", DATA)
md5 = hashlib.md5(DATA.read_bytes()).hexdigest()
df = pd.read_csv(DATA)
checks = {
    "file": str(DATA.name), "md5": md5, "rows": len(df), "columns": df.shape[1],
    "fraud_count": int(df.Class.sum()), "legit_count": int((df.Class == 0).sum()),
    "fraud_prevalence_pct": round(100 * df.Class.mean(), 4), "missing_values": int(df.isna().sum().sum()),
    "duplicate_rows": int(df.duplicated().sum()),
}
assert checks["rows"] == 284807 and checks["fraud_count"] == 492, "Dataset counts differ from the published description"
# Optional cross-check with the OpenML copy (data_id 1597)
arff = ROOT / "data" / "creditcard_openml.arff"
if arff.exists():
    try:
        from scipy.io import arff as sarff
        od = pd.DataFrame(sarff.loadarff(str(arff))[0])
        od["Class"] = od["Class"].astype(str).str.strip("'\"b").astype(int)
        common = [c for c in df.columns if c in od.columns]
        checks["openml_rows"] = len(od)
        checks["openml_fraud_count"] = int(od.Class.sum())
        checks["openml_identical_to_main_file"] = bool(len(od) == len(df) and np.allclose(
            od[common].to_numpy(dtype=float), df[common].to_numpy(dtype=float), rtol=1e-6, atol=1e-9))
    except Exception as e:  # incomplete download etc.
        checks["openml_crosscheck"] = f"skipped: {type(e).__name__}"
print(json.dumps(checks, indent=2))
(RES / "dataset_verification.json").write_text(json.dumps(checks, indent=2))
print(df.describe().T[["mean", "std", "min", "max"]].head(6).round(3).to_string())

# %% [markdown]
# ## 2. Exploratory data analysis (class distribution)

# %%
fig, ax = plt.subplots(1, 2, figsize=(11, 4))
counts = df.Class.value_counts().sort_index()
ax[0].bar(["Legitimate (0)", "Fraud (1)"], counts.values, color=["#4C72B0", "#C44E52"])
for i, v in enumerate(counts.values):
    ax[0].text(i, v, f"{v:,}", ha="center", va="bottom")
ax[0].set_title("Class distribution (linear scale)")
ax[0].set_ylabel("Transactions")
ax[1].bar(["Legitimate (0)", "Fraud (1)"], counts.values, color=["#4C72B0", "#C44E52"])
ax[1].set_yscale("log")
ax[1].set_title(f"Class distribution (log scale) - fraud = {100*df.Class.mean():.3f}%")
plt.tight_layout()
plt.savefig(FIG / "01_class_distribution.png", dpi=150)
plt.close()

fig, ax = plt.subplots(1, 2, figsize=(11, 4))
for c, col in [(0, "#4C72B0"), (1, "#C44E52")]:
    ax[0].hist(np.log1p(df.loc[df.Class == c, "Amount"]), bins=50, alpha=.6, density=True, color=col, label=f"Class {c}")
    ax[1].hist(df.loc[df.Class == c, "Time"] / 3600, bins=48, alpha=.6, density=True, color=col, label=f"Class {c}")
ax[0].set_xlabel("log(1 + Amount)")
ax[0].set_title("Transaction amount by class")
ax[0].legend()
ax[1].set_xlabel("Hours since first transaction")
ax[1].set_title("Transaction time by class")
ax[1].legend()
plt.tight_layout()
plt.savefig(FIG / "02_amount_time_by_class.png", dpi=150)
plt.close()
eda = df.groupby("Class")[["Amount"]].agg(["count", "mean", "median", "max"]).round(2)
eda.to_csv(RES / "eda_amount_by_class.csv")
print(eda)

# %% [markdown]
# ## 3. Stratified 70 / 15 / 15 split
# The proposal's split. Stratification keeps the 0.17% fraud rate in every subset. Imbalance handling is applied to
# the **training** data only; validation and test keep their natural distribution.

# %%
FEATURES = [c for c in df.columns if c != "Class"]
X, y = df[FEATURES], df["Class"]
X_train, X_tmp, y_train, y_tmp = train_test_split(X, y, test_size=0.30, stratify=y, random_state=SEED)
X_val, X_test, y_val, y_test = train_test_split(X_tmp, y_tmp, test_size=0.50, stratify=y_tmp, random_state=SEED)
split = pd.DataFrame({"subset": ["train", "validation", "test"],
                      "rows": [len(y_train), len(y_val), len(y_test)],
                      "fraud": [int(y_train.sum()), int(y_val.sum()), int(y_test.sum())]})
split["fraud_pct"] = (100 * split.fraud / split.rows).round(4)
split.to_csv(RES / "split_summary.csv", index=False)
print(split.to_string(index=False))

fig, ax = plt.subplots(figsize=(6, 3.5))
ax.bar(split.subset, split.fraud_pct, color="#C44E52")
ax.set_ylabel("Fraud prevalence (%)")
ax.set_title("Fraud prevalence preserved by stratified split")
for i, v in enumerate(split.fraud_pct): ax.text(i, v, f"{v:.3f}%", ha="center", va="bottom")
plt.tight_layout()
plt.savefig(FIG / "03_split_prevalence.png", dpi=150)
plt.close()

# %% [markdown]
# ## 4. Models, imbalance conditions and pipelines
# * **Scaling:** z-score on `Time` and `Amount` only (V1-V28 are PCA outputs); fitted on training data inside every pipeline
#   (so, inside every CV fold - no leakage).
# * **Baseline:** no imbalance handling. **SMOTE:** oversampling to a minority:majority ratio of 0.10 on the training fold only
#   (methodological decision - a "specified proportion" as the proposal states, cheaper and less distorting than 1:1).
#   **Cost-sensitive:** `class_weight="balanced"` (LR, RF, SVM) / `scale_pos_weight = n_neg/n_pos` (XGBoost).
# * **SVM (methodological decision):** an RBF-kernel SVC cannot be trained on all ~200k rows in a sensible time on a student
#   machine (training cost grows roughly quadratically with sample size), so the main SVM is an **RBF SVC trained on a
#   stratified 50,000-row subsample of the training set** (as planned in the Aug 2026 methodology refinement).
#   A **LinearSVC on the full training set** is reported as a supplementary variant.
# * **Gradient boosting:** XGBoost (the proposal allowed XGBoost or LightGBM).
# * Hyperparameters are chosen by a small, documented grid search scored on the validation set (section 5).

# %%
SCALE_COLS = ["Time", "Amount"]
def preproc():
    return ColumnTransformer([("scale", StandardScaler(), SCALE_COLS)], remainder="passthrough")

N_NEG, N_POS = int((y_train == 0).sum()), int(y_train.sum())
def make_estimator(model, strategy, **hp):
    cs = strategy == "Cost-sensitive"
    if model == "Logistic Regression":
        return LogisticRegression(**{**dict(max_iter=2000, C=1.0), **hp}, class_weight="balanced" if cs else None, random_state=SEED)
    if model == "Random Forest":
        return RandomForestClassifier(**{**dict(n_estimators=100), **hp}, n_jobs=-1, random_state=SEED,
                                      class_weight="balanced_subsample" if cs else None)
    if model == "SVM (RBF, 50k subsample)":
        return SVC(**{**dict(kernel="rbf", C=1.0, gamma="scale"), **hp}, cache_size=1500,
                   class_weight="balanced" if cs else None, random_state=SEED)
    if model == "SVM (linear, full train)":
        return LinearSVC(**{**dict(C=1.0), **hp}, dual=False, max_iter=5000, class_weight="balanced" if cs else None, random_state=SEED)
    if model == "Gradient Boosting (XGBoost)":
        return XGBClassifier(**{**dict(n_estimators=300, max_depth=6, learning_rate=0.1), **hp}, subsample=0.8, colsample_bytree=0.8,
                             tree_method="hist", eval_metric="aucpr", random_state=SEED, n_jobs=8,
                             scale_pos_weight=(N_NEG / N_POS) if cs else 1.0)
    raise ValueError(model)

BEST_HP = {}   # filled by the validation-set search in section 5
def make_pipeline(model, strategy):
    steps = [("prep", preproc())]
    if strategy == "SMOTE":
        steps.append(("smote", SMOTE(sampling_strategy=0.10, k_neighbors=5, random_state=SEED)))
    steps.append(("clf", make_estimator(model, strategy, **BEST_HP.get((model, strategy), {}))))
    return Pipeline(steps)

MODELS = ["Logistic Regression", "Random Forest", "SVM (RBF, 50k subsample)", "Gradient Boosting (XGBoost)",
          "SVM (linear, full train)"]
STRATEGIES = ["Baseline", "SMOTE", "Cost-sensitive"]

# stratified 50k subsample of the training set for the RBF-SVM (keeps the fraud prevalence)
sub_idx, _ = train_test_split(np.arange(len(y_train)), train_size=50000, stratify=y_train, random_state=SEED)
X_svm, y_svm = X_train.iloc[sub_idx], y_train.iloc[sub_idx]
print(f"SVM-RBF subsample: {len(y_svm):,} rows, {int(y_svm.sum())} fraud ({100*y_svm.mean():.3f}%)")
def train_data(model):
    return (X_svm, y_svm) if model.startswith("SVM (RBF") else (X_train, y_train)

def scores(pipe, Xe):
    clf = pipe.named_steps["clf"]
    return pipe.predict_proba(Xe)[:, 1] if hasattr(clf, "predict_proba") else pipe.decision_function(Xe)

# %% [markdown]
# ## 5. Hyperparameter selection on the validation set
# The proposal plans hyperparameter optimisation on the validation set. Each model/condition is fitted on the training
# data for every configuration in a small, pre-specified grid (kept small for compute - a resource-based limitation) and the
# configuration with the highest **validation PR-AUC** is kept. The test set is not used here.

# %%
GRIDS = {
    "Logistic Regression": [dict(C=c) for c in [0.01, 0.1, 1.0, 10.0]],
    "Random Forest": [dict(max_depth=d, min_samples_leaf=l) for d in [None, 12] for l in [1, 5]],
    "SVM (RBF, 50k subsample)": [dict(C=c, gamma=g) for c in [1.0, 10.0] for g in ["scale", 0.01]],
    "SVM (linear, full train)": [dict(C=c) for c in [0.01, 0.1, 1.0, 10.0]],
    "Gradient Boosting (XGBoost)": [dict(max_depth=d, learning_rate=lr) for d in [3, 6] for lr in [0.05, 0.1]],
}
tune_rows = []
for m in MODELS:
    for s in STRATEGIES:
        best, Xt, yt = None, *train_data(m)
        for hp in GRIDS[m]:
            BEST_HP[(m, s)] = hp
            ap = average_precision_score(y_val, scores(make_pipeline(m, s).fit(Xt, yt), X_val))
            tune_rows.append(dict(model=m, strategy=s, params=json.dumps(hp), val_pr_auc=ap))
            if best is None or ap > best[1]: best = (hp, ap)
        BEST_HP[(m, s)] = best[0]
        print(f"tuned {m:30s} {s:15s} -> {best[0]}  val PR-AUC {best[1]:.4f}", flush=True)
tune_df = pd.DataFrame(tune_rows)
tune_df.to_csv(RES / "hyperparameter_search_validation.csv", index=False)
chosen = pd.DataFrame([dict(model=m, strategy=s, chosen_params=json.dumps(hp, default=str)) for (m, s), hp in BEST_HP.items()])
chosen.to_csv(RES / "chosen_hyperparameters.csv", index=False)

# %% [markdown]
# ## 6. Stratified 5-fold cross-validation on the training data
# SMOTE and scaling are refitted inside each fold. Reported as mean +/- SD (default 0.5 / 0.0 decision threshold for
# precision, recall, F1).

# %%
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
cv_rows = []
t_cv = time.time()
for m in MODELS:
    for s in STRATEGIES:
        t0 = time.time()
        Xt, yt = train_data(m)
        r = cross_validate(make_pipeline(m, s), Xt, yt, cv=skf, n_jobs=1,
                           scoring={"pr_auc": "average_precision", "roc_auc": "roc_auc", "f1": "f1",
                                    "precision": "precision", "recall": "recall"})
        row = {"model": m, "strategy": s, "fit_time_s_per_fold": round(float(np.mean(r["fit_time"])), 1)}
        for k in ["pr_auc", "roc_auc", "f1", "precision", "recall"]:
            row[f"{k}_mean"] = float(np.mean(r[f"test_{k}"]))
            row[f"{k}_sd"] = float(np.std(r[f"test_{k}"], ddof=1))
        cv_rows.append(row)
        print(f"CV {m:30s} {s:15s} PR-AUC {row['pr_auc_mean']:.3f}+/-{row['pr_auc_sd']:.3f} "
                                   f"F1 {row['f1_mean']:.3f}  ({time.time()-t0:.0f}s)", flush=True)
cv_df = pd.DataFrame(cv_rows)
cv_df.to_csv(RES / "cv_results_5fold_train.csv", index=False)
print(f"CV total {time.time()-t_cv:.0f}s")

# %% [markdown]
# ## 7. Final fit on the full training set; validation and test scoring
# Threshold analysis: for each model the decision threshold maximising F1 on the **validation** set is chosen and then
# applied once to the test set. Test metrics are also reported at the default threshold (0.5 for probabilities, 0 for SVM scores).

# %%
fitted, S_val, S_test, fit_times = {}, {}, {}, {}
for m in MODELS:
    for s in STRATEGIES:
        t0 = time.time()
        Xt, yt = train_data(m)
        p = make_pipeline(m, s).fit(Xt, yt)
        fitted[(m, s)] = p
        S_val[(m, s)] = scores(p, X_val)
        S_test[(m, s)] = scores(p, X_test)
        fit_times[(m, s)] = time.time() - t0
        print(f"fit {m:30s} {s:15s} {fit_times[(m, s)]:.0f}s", flush=True)
np.savez_compressed(RES / "scores_val_test.npz", y_val=y_val.to_numpy(), y_test=y_test.to_numpy(),
                    **{f"val|{m}|{s}": v for (m, s), v in S_val.items()},
                    **{f"test|{m}|{s}": v for (m, s), v in S_test.items()})

def default_thr(m): return 0.0 if m.startswith("SVM (linear") or m.startswith("SVM (RBF") else 0.5
def best_f1_threshold(yv, sv):
    pr, rc, th = precision_recall_curve(yv, sv)
    f1 = 2 * pr[:-1] * rc[:-1] / np.clip(pr[:-1] + rc[:-1], 1e-12, None)
    return float(th[int(np.nanargmax(f1))])

def metric_row(yt_, sc, thr):
    pred = (sc >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(yt_, pred, labels=[0, 1]).ravel()
    return dict(precision=precision_score(yt_, pred, zero_division=0), recall=recall_score(yt_, pred),
                f1=f1_score(yt_, pred), mcc=matthews_corrcoef(yt_, pred), TN=int(tn), FP=int(fp), FN=int(fn), TP=int(tp))

rows_def, rows_tuned = [], []
for (m, s), sv in S_test.items():
    thr_d = default_thr(m)
    thr_t = best_f1_threshold(y_val.to_numpy(), S_val[(m, s)])
    base = dict(model=m, strategy=s, roc_auc=roc_auc_score(y_test, sv), pr_auc=average_precision_score(y_test, sv),
                val_pr_auc=average_precision_score(y_val, S_val[(m, s)]), fit_time_s=round(fit_times[(m, s)], 1))
    rows_def.append({**base, "threshold": thr_d, **metric_row(y_test.to_numpy(), sv, thr_d)})
    rows_tuned.append({**base, "threshold": thr_t, **metric_row(y_test.to_numpy(), sv, thr_t)})
test_default = pd.DataFrame(rows_def)
test_tuned = pd.DataFrame(rows_tuned)
test_default.to_csv(RES / "test_metrics_default_threshold.csv", index=False)
test_tuned.to_csv(RES / "test_metrics_val_tuned_threshold.csv", index=False)
cols = ["model", "strategy", "precision", "recall", "f1", "roc_auc", "pr_auc", "mcc", "TN", "FP", "FN", "TP"]
print("\nTEST SET - default threshold\n", test_default[cols].round(4).to_string(index=False))
print("\nTEST SET - validation-F1-optimal threshold\n", test_tuned[cols + ["threshold"]].round(4).to_string(index=False))

# %% [markdown]
# ## 8. Model selection (on validation PR-AUC, never on the test set)

# %%
sel = test_default.sort_values("val_pr_auc", ascending=False).reset_index(drop=True)
print(sel[["model", "strategy", "val_pr_auc", "pr_auc", "f1", "recall", "precision"]].round(4).head(6).to_string(index=False))
BEST = (sel.loc[0, "model"], sel.loc[0, "strategy"])
print("Best by validation PR-AUC:", BEST)
test_rank = test_default.sort_values("pr_auc", ascending=False).iloc[0][["model", "strategy"]].tolist()
print("Best by test PR-AUC      :", test_rank)
(RES / "best_model.json").write_text(json.dumps({"best_by_validation_pr_auc": list(BEST),
                                                 "best_by_test_pr_auc": test_rank}, indent=2))

# %% [markdown]
# ## 9. Effect of imbalance handling (change vs the baseline condition)

# %%
piv = test_default.pivot(index="model", columns="strategy", values=["pr_auc", "f1", "recall", "precision"])
delta_rows = []
for m in MODELS:
    for s in ["SMOTE", "Cost-sensitive"]:
        b = test_default[(test_default.model == m) & (test_default.strategy == "Baseline")].iloc[0]
        r = test_default[(test_default.model == m) & (test_default.strategy == s)].iloc[0]
        delta_rows.append(dict(model=m, strategy=s, **{f"d_{k}": r[k] - b[k] for k in ["pr_auc", "roc_auc", "f1", "recall", "precision", "mcc"]},
                               d_FP=int(r.FP - b.FP), d_FN=int(r.FN - b.FN)))
delta = pd.DataFrame(delta_rows)
delta.to_csv(RES / "imbalance_effect_vs_baseline.csv", index=False)
print(delta.round(4).to_string(index=False))

# %% [markdown]
# ## 10. Uncertainty: bootstrap 95% CIs (1,000 stratified resamples of the test set) and McNemar tests vs the best model
# The test set contains only ~74 fraud cases, so intervals are wide - interpret differences with care.

# %%
yt_np = y_test.to_numpy()
pos = np.where(yt_np == 1)[0]
neg = np.where(yt_np == 0)[0]
def boot_ci(key, n=1000):
    sc = S_test[key]
    thr = default_thr(key[0])
    rng = np.random.default_rng(SEED)
    idxs = [np.concatenate([rng.choice(pos, len(pos)), rng.choice(neg, len(neg))]) for _ in range(n)]
    def one(ix): return (average_precision_score(yt_np[ix], sc[ix]), f1_score(yt_np[ix], sc[ix] >= thr))
    out = np.array([one(ix) for ix in idxs])
    return np.percentile(out[:, 0], [2.5, 97.5]), np.percentile(out[:, 1], [2.5, 97.5])
ci_res = Parallel(n_jobs=4)(delayed(boot_ci)(k) for k in S_test)
ci_rows = [dict(model=k[0], strategy=k[1], pr_auc_lo=a[0], pr_auc_hi=a[1], f1_lo=b[0], f1_hi=b[1])
           for k, (a, b) in zip(S_test, ci_res)]
ci_df = pd.DataFrame(ci_rows)
ci_df.to_csv(RES / "bootstrap_ci_test.csv", index=False)

pred_best = (S_test[BEST] >= default_thr(BEST[0])).astype(int)
mc_rows = []
for k, sc in S_test.items():
    if k == BEST: continue
    pk = (sc >= default_thr(k[0])).astype(int)
    b01 = int(((pred_best == yt_np) & (pk != yt_np)).sum())
    b10 = int(((pred_best != yt_np) & (pk == yt_np)).sum())
    mc_rows.append(dict(best=f"{BEST[0]} / {BEST[1]}", other=f"{k[0]} / {k[1]}", best_right_other_wrong=b01,
                        best_wrong_other_right=b10, p_value_exact=float(mcnemar([[0, b01], [b10, 0]], exact=True).pvalue)))
mc_df = pd.DataFrame(mc_rows)
mc_df.to_csv(RES / "mcnemar_vs_best.csv", index=False)
print(ci_df.round(4).to_string(index=False))
print(mc_df.round(4).to_string(index=False))

# %% [markdown]
# ## 11. Figures: PR curves, ROC curves, confusion matrices, feature importance, threshold analysis

# %%
palette = {"Baseline": "#4C72B0", "SMOTE": "#DD8452", "Cost-sensitive": "#55A868"}
def curve_grid(kind, fname):
    fig, axes = plt.subplots(2, 3, figsize=(16, 9))
    axes = axes.ravel()
    for ax, m in zip(axes, MODELS):
        for s in STRATEGIES:
            sc = S_test[(m, s)]
            if kind == "pr":
                p, r, _ = precision_recall_curve(yt_np, sc)
                ax.plot(r, p, color=palette[s], label=f"{s} (AP={average_precision_score(yt_np, sc):.3f})")
            else:
                f, t, _ = roc_curve(yt_np, sc)
                ax.plot(f, t, color=palette[s], label=f"{s} (AUC={roc_auc_score(yt_np, sc):.3f})")
        if kind == "roc": ax.plot([0, 1], [0, 1], "k--", lw=.8)
        ax.set_title(m, fontsize=10)
        ax.legend(fontsize=8, loc="lower left")
        ax.set_xlabel("Recall" if kind == "pr" else "False positive rate")
        ax.set_ylabel("Precision" if kind == "pr" else "True positive rate")
    axes[-1].axis("off")
    fig.suptitle(("Precision-recall" if kind == "pr" else "ROC") + " curves - held-out test set", fontsize=13)
    plt.tight_layout()
    plt.savefig(FIG / fname, dpi=150)
    plt.close()
curve_grid("pr", "04_pr_curves.png")
curve_grid("roc", "05_roc_curves.png")

fig, axes = plt.subplots(len(MODELS), 3, figsize=(11, 3.2 * len(MODELS)))
for i, m in enumerate(MODELS):
    for j, s in enumerate(STRATEGIES):
        r = test_default[(test_default.model == m) & (test_default.strategy == s)].iloc[0]
        cm = np.array([[r.TN, r.FP], [r.FN, r.TP]])
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, ax=axes[i, j],
                    xticklabels=["Pred legit", "Pred fraud"], yticklabels=["True legit", "True fraud"])
        axes[i, j].set_title(f"{m}\n{s}", fontsize=8)
plt.suptitle("Confusion matrices - test set, default threshold", y=1.0)
plt.tight_layout()
plt.savefig(FIG / "06_confusion_matrices.png", dpi=130)
plt.close()

mat = test_default.pivot(index="model", columns="strategy", values="pr_auc").loc[MODELS, STRATEGIES]
fig, ax = plt.subplots(1, 2, figsize=(12, 3.8))
sns.heatmap(mat, annot=True, fmt=".3f", cmap="viridis", ax=ax[0])
ax[0].set_title("Test PR-AUC")
ax[0].set_ylabel("")
mat2 = test_default.pivot(index="model", columns="strategy", values="f1").loc[MODELS, STRATEGIES]
sns.heatmap(mat2, annot=True, fmt=".3f", cmap="viridis", ax=ax[1])
ax[1].set_title("Test F1 (default threshold)")
ax[1].set_ylabel("")
ax[1].set_yticklabels([])
plt.tight_layout()
plt.savefig(FIG / "07_metric_heatmaps.png", dpi=150)
plt.close()

# feature importance: tree models (baseline condition) and LR coefficients (cost-sensitive)
names = SCALE_COLS + [c for c in FEATURES if c not in SCALE_COLS]
fi = {}
fi["Random Forest (Baseline)"] = pd.Series(fitted[("Random Forest", "Baseline")].named_steps["clf"].feature_importances_, index=names)
fi["XGBoost (Baseline)"] = pd.Series(fitted[("Gradient Boosting (XGBoost)", "Baseline")].named_steps["clf"].feature_importances_, index=names)
fi["Logistic Regression coef. (Cost-sensitive)"] = pd.Series(
    np.abs(fitted[("Logistic Regression", "Cost-sensitive")].named_steps["clf"].coef_[0]), index=names)
fi_df = pd.DataFrame(fi)
fi_df.to_csv(RES / "feature_importances.csv")
fig, axes = plt.subplots(1, 3, figsize=(17, 6))
for ax, (k, v) in zip(axes, fi.items()):
    v.sort_values().tail(12).plot.barh(ax=ax, color="#4C72B0")
    ax.set_title(k, fontsize=10)
plt.suptitle("Top 12 feature importances (anonymised features: interpret as statistical patterns only)")
plt.tight_layout()
plt.savefig(FIG / "08_feature_importance.png", dpi=150)
plt.close()

# threshold analysis for the model selected on validation PR-AUC
sv, st = S_val[BEST], S_test[BEST]
ths = np.unique(np.quantile(st, np.linspace(0.5, 0.99999, 400)))
curve = pd.DataFrame([dict(threshold=t, precision=precision_score(yt_np, st >= t, zero_division=0),
                           recall=recall_score(yt_np, st >= t), f1=f1_score(yt_np, st >= t),
                           FP=int(((st >= t) & (yt_np == 0)).sum()), FN=int(((st < t) & (yt_np == 1)).sum())) for t in ths])
curve.to_csv(RES / "threshold_curve_best_model.csv", index=False)
thr_opt = best_f1_threshold(y_val.to_numpy(), sv)
# operating points chosen on validation: max-F1, and highest precision with recall >= 0.90
pr_v, rc_v, th_v = precision_recall_curve(y_val, sv)
ok = np.where(rc_v[:-1] >= 0.90)[0]
thr_r90 = float(th_v[ok[np.argmax(pr_v[:-1][ok])]]) if len(ok) else np.nan
ops = []
for name, t in [("Default", default_thr(BEST[0])), ("Max-F1 on validation", thr_opt), ("Recall>=0.90 on validation", thr_r90)]:
    ops.append(dict(operating_point=name, threshold=t, **metric_row(yt_np, st, t)))
ops_df = pd.DataFrame(ops)
ops_df.to_csv(RES / "threshold_operating_points_best_model.csv", index=False)
print(f"Best model: {BEST}")
print(ops_df.round(4).to_string(index=False))
fig, ax = plt.subplots(1, 2, figsize=(13, 4.5))
ax[0].plot(curve.threshold, curve.precision, label="Precision")
ax[0].plot(curve.threshold, curve.recall, label="Recall")
ax[0].plot(curve.threshold, curve.f1, label="F1")
for name, t in [("val max-F1", thr_opt), ("val recall>=.90", thr_r90)]:
    if not np.isnan(t):
        ax[0].axvline(t, ls="--", lw=.8, color="grey")
        ax[0].text(t, .02, name, rotation=90, fontsize=7)
ax[0].set_xlabel("Decision threshold")
ax[0].set_title(f"Threshold analysis - {BEST[0]} / {BEST[1]}")
ax[0].legend()
ax[1].plot(curve.threshold, curve.FP, label="False positives")
ax[1].plot(curve.threshold, curve.FN, label="False negatives")
ax[1].set_yscale("symlog")
ax[1].set_xlabel("Decision threshold")
ax[1].set_title("Errors vs threshold (test set)")
ax[1].legend()
plt.tight_layout()
plt.savefig(FIG / "09_threshold_analysis.png", dpi=150)
plt.close()

# bar chart of CV vs test PR-AUC
cvp = cv_df.assign(label=cv_df.model + "\n" + cv_df.strategy)
fig, ax = plt.subplots(figsize=(15, 4.5))
x = np.arange(len(cvp))
ax.bar(x - .2, cvp.pr_auc_mean, .4, yerr=cvp.pr_auc_sd, label="5-fold CV (train)", color="#8172B2")
ax.bar(x + .2, [test_default[(test_default.model == r.model) & (test_default.strategy == r.strategy)].pr_auc.iloc[0] for r in cvp.itertuples()],
       .4, label="Test", color="#CCB974")
ax.set_xticks(x)
ax.set_xticklabels(cvp.label, rotation=90, fontsize=7)
ax.set_ylabel("PR-AUC")
ax.legend()
ax.set_title("PR-AUC: cross-validation (mean +/- SD) vs held-out test")
plt.tight_layout()
plt.savefig(FIG / "10_cv_vs_test_prauc.png", dpi=150)
plt.close()

# %% [markdown]
# ## 12. Headline summary table (the table used in the report)

# %%
summary = test_default[["model", "strategy", "precision", "recall", "f1", "roc_auc", "pr_auc", "mcc", "TN", "FP", "FN", "TP"]].merge(
    cv_df[["model", "strategy", "pr_auc_mean", "pr_auc_sd"]], on=["model", "strategy"]).merge(
    test_tuned[["model", "strategy", "threshold", "precision", "recall", "f1"]].rename(
        columns={"threshold": "tuned_threshold", "precision": "tuned_precision", "recall": "tuned_recall", "f1": "tuned_f1"}),
    on=["model", "strategy"])
summary["model"] = pd.Categorical(summary.model, MODELS, ordered=True)
summary["strategy"] = pd.Categorical(summary.strategy, STRATEGIES, ordered=True)
summary = summary.sort_values(["model", "strategy"]).reset_index(drop=True)
summary.to_csv(RES / "summary_table.csv", index=False)
print(summary.round(4).to_string(index=False))
fig, ax = plt.subplots(figsize=(15, 4.8))
ax.axis("off")
show = summary[["model", "strategy", "precision", "recall", "f1", "roc_auc", "pr_auc", "mcc", "FP", "FN"]].copy()
for c in ["precision", "recall", "f1", "roc_auc", "pr_auc", "mcc"]: show[c] = show[c].map("{:.3f}".format)
t = ax.table(cellText=show.values, colLabels=show.columns, loc="center", cellLoc="center")
t.auto_set_font_size(False)
t.set_fontsize(8)
t.scale(1, 1.3)
plt.tight_layout()
plt.savefig(FIG / "11_summary_table.png", dpi=150)
plt.close()
print("DONE")
